# FML-Lab-Report
FML-lab report template
1. Upload the files to Overleaf
2. Compile and run main.tex
3. To prepare a report for Lab-X go inside Lab-X folder and edit main.tex
4. Keep all the codes under Lab-X. 
